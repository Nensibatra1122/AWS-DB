# Use-a-Pre-trained-Image-Classifier-to-Identify-Dog-Breeds
This project is part of Udacity's 'AI Programming with Python' Nanodegree.

Here, I used a created image classifier to identify dog breeds.
